package com.example.sharedpreference;

import android.content.Context;
import android.content.SharedPreferences;

public class MySharedPrefs {
    public static final String USER_NAME = "userName";
    public static final String PASS_WORD = "passWord";

    public static boolean setUserNamePW(Context context, String userName, String passWord){
        SharedPreferences prefs = context.getSharedPreferences("MyPrefs", context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putString(USER_NAME, userName);
        editor.putString(PASS_WORD, passWord);
        return editor.commit();
    }

    public static String[] getUserNamePW(Context context){
        SharedPreferences prefs = context.getSharedPreferences("MyPrefs", context.MODE_PRIVATE);

        String[] userNamePW = new String[2];
        userNamePW[0] = prefs.getString(USER_NAME, "");
        userNamePW[1] = prefs.getString(PASS_WORD, "");
        return userNamePW;
    }

    public static boolean removeUserNamePW(Context context){
        SharedPreferences prefs = context.getSharedPreferences("MyPrefs", context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.remove(USER_NAME);
        editor.remove(PASS_WORD);
        return editor.commit();
    }}



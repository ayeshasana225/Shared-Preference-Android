package com.example.sharedpreference;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText userName, password;
    Button save, restore, delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userName = findViewById(R.id.user_name);
        password = findViewById(R.id.pass_word);
        save = findViewById(R.id.save_btn);
        restore = findViewById(R.id.save_btn);
        delete = findViewById(R.id.delete_btn);
    }

    public void saveButton(View view){
        String userNameStr = userName.getText().toString();
        String passWordStr = password.getText().toString();
        if(!userNameStr.isEmpty() &&
                !passWordStr.isEmpty()){
            if(MySharedPrefs.setUserNamePW(this, userNameStr, passWordStr)){
                Toast.makeText(this, "Successfully Saved", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Not Successfully Saved", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void restoreButton(View view){
        String[] userNamePW = MySharedPrefs.getUserNamePW(this);
        if(!userNamePW[0].isEmpty() && !userNamePW[0].isEmpty()){
            userName.setText(userNamePW[0]);
            password.setText(userNamePW[1]);
        }
    }

    public void deleteButton(View view){
        if(MySharedPrefs.removeUserNamePW(this)){
            userName.setText("");
            password.setText("");
            Toast.makeText(this, "Successfully Deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Not Successfully Deleted", Toast.LENGTH_SHORT).show();
        }
    }
}
